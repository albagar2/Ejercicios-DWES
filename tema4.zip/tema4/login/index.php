<?php

echo "DNI: ".$_COOKIE["dni"];
echo "Nombre: ".$_COOKIE["nombre"];
echo "Apellidos: ".$_COOKIE["apellidos"];

